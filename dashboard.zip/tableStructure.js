//JS File for displaying input fields in Data Table
$(document).ready(function () {
    var table = $('#documentTable').DataTable();
    
    // Handle form submission
    $('#submitBtn').on('click', function (e) {
      e.preventDefault();
      
      // Get form input values
      var type = $('#uploadDocType').val();
      var subject = $('#uploadFrom').val();
      var from = $('#uploadTo').val();
      var datetime = $('#uploadSubject').val();
      var status = $('#uploadStatus').val();
      var assignee = $('#uploadAssignee').val();
      
      // Add the form data to the DataTable
      table.row.add([
        type,
        subject,
        from,
        datetime,
        status,
        assignee
    // Redraw the table without resetting the paging
      ]).draw(false); 
      
      // Clear the form inputs after submission
      $('#documentForm')[0].reset();
    });
  });
  