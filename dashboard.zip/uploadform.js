 // Get modal element
 const modal = document.getElementById('uploadModal');
 // Get open modal button
 const uploadBtn = document.getElementById('uploadBtn');
 // Get close button
 const closeBtn = document.getElementById('cancelBtn');

 const submitBtn = document.getElementById('submitBtn');

 // Listen for click on upload button
 uploadBtn.addEventListener('click', function() {
     modal.style.display = 'flex';
 });

 // Listen for click on close button
 closeBtn.addEventListener('click', function() {
     modal.style.display = 'none';
 });

 // Close the modal if user clicks outside of it
 window.addEventListener('click', function(event) {
     if (event.target === modal) {
         modal.style.display = 'none';
     }
 });

